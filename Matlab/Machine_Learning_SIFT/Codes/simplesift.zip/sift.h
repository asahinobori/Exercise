#ifndef SIFT_H
#define SIFT_H

#include <cxcore.h>
#include <stdio.h>


#ifndef ABS
#define ABS(x) (((x) < 0)? -(x) : (x))
#endif

#define FEATURE_MAX_D 128

#define SIFT_INTVLS 3

#define SIFT_SIGMA 1.6

#define SIFT_CONTR_THR 0.04

#define SIFT_CURV_THR 10

#define SIFT_IMG_DBL 1

#define SIFT_DESCR_WIDTH 4

#define SIFT_DESCR_HIST_BINS 8

#define SIFT_INIT_SIGMA 0.5

#define SIFT_IMG_BORDER 5

#define SIFT_MAX_INTERP_STEPS 5

#define SIFT_ORI_HIST_BINS 36

#define SIFT_ORI_SIG_FCTR 1.5

#define SIFT_ORI_RADIUS 3.0 * SIFT_ORI_SIG_FCTR

#define SIFT_ORI_SMOOTH_PASSES 2

#define SIFT_ORI_PEAK_RATIO 0.8

#define SIFT_DESCR_SCL_FCTR 3.0

#define SIFT_DESCR_MAG_THR 0.2

#define SIFT_INT_DESCR_FCTR 512.0

#define feat_detection_data(f) ( (struct detection_data*)(f->feature_data) )


static inline float pixval32f(IplImage* img, int r, int c) {
  return ((float*)(img->imageData + img->widthStep*r))[c];
}


struct detection_data
{
    int r;
    int c;
    int octv;
    int intvl;
    double subintvl;
    double scl_octv;
};

struct feature
{
    double x;
    double y;
    double scl;
    double ori;
    int d;                          /*描述子长度*/
    double descr[FEATURE_MAX_D];    /*描述子*/
    CvPoint2D64f img_pt;
    void* feature_data;
};

extern int sift_features(IplImage* img, struct feature** feat);

extern int _sift_features(IplImage* img, struct feature** feat, int intvls,
                          double sigma, double contr_thr, int curv_thr,
                          int img_dbl, int descr_width, int descr_hist_bins);
#endif
