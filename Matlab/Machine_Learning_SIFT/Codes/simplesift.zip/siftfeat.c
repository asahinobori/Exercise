/*
    This program detects image features using SIFT keypoints.
*/

#include "sift.h"
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <stdarg.h>
#include <highgui.h>



#define OPTIONS "o:h"

static void usage(char* name);
static void arg_parse(int argc, char** argv);
static void fatal_error(char* format, ...);
static char* basename(const char* pathname);
static int export_features(char* filename, struct feature* feat, int n);
static int export_lowe_features(char* filename, struct feature* feat, int n);

char* pname;
char* img_file_name;
char* out_file_name = NULL;
int intvls = SIFT_INTVLS;
double sigma = SIFT_SIGMA;
double contr_thr = SIFT_CONTR_THR;
int curv_thr = SIFT_CURV_THR;
int img_dbl = SIFT_IMG_DBL;
int descr_width = SIFT_DESCR_WIDTH;
int descr_hist_bins = SIFT_DESCR_HIST_BINS;


int main(int argc, char** argv) {
  IplImage* img;
  struct feature* features;
  int n = 0;

  arg_parse(argc, argv);

  fprintf(stderr, "Finding SIFT features...\n");
  img = cvLoadImage(img_file_name, 1);
  if (!img)
      fatal_error("unable to load image from %s", img_file_name);
  n = _sift_features(img, &features, intvls, sigma, contr_thr, curv_thr, 
                     img_dbl, descr_width, descr_hist_bins);
  fprintf(stderr, "Found %d features.\n", n);

//  if (display) {
//      draw_features(img, features, n);
//      display_big_img(img, img_file_name);
//      cvWaitKey(0);
//  }

  if (out_file_name != NULL)
      export_features(out_file_name, features, n);
//  if (out_img_name != NULL)
//      cvSaveImage(out_img_name, img, NULL);
  return 0;
}

static void usage(char* name) {
  fprintf(stderr, "%s: detect SIFT keypoints in an image\n\n", name);
  fprintf(stderr, "Usage: %s [options] <img_file>\n", name);
  fprintf(stderr, "Options:\n");
  fprintf(stderr, "  -h                 Display this message and exit\n");
  fprintf(stderr, "  -o <out_file>      Output keypoints to text file\n");
}

static void arg_parse(int argc, char** argv) {
  pname = basename(argv[0]);

  while (1) {
    char* arg_check;
    int arg = getopt(argc, argv, OPTIONS);
    if (arg == -1)
      break;

    switch (arg) {
      case 'o':
        if (! optarg)
          fatal_error("error parsing arguments at -%c\n"    \
                      "Try '%s -h' for help.", arg, pname);
        out_file_name = optarg;
        break;

      case 'h':
        usage(pname);
        exit(0);
        break;

      default :
        fatal_error("-%c: invalid option.\nTry '%s -h' for help.",
                    optopt, pname);
    }
  }
  if (argc - optind < 1)
    fatal_error("no input file specified.\nTry '%s -h' for help.", pname);

  if (argc - optind > 1)
    fatal_error("too many arguments.\nTry '%s -h' for help.", pname);

  img_file_name = argv[optind];
}

static char* basename(const char* pathname) {
  char* base, * last_slash;

  last_slash = strrchr(pathname, '/');
  if (! last_slash) {
    base = calloc(strlen(pathname) + 1, sizeof(char));
    strcpy(base, pathname);
  }
  else {
    base = calloc(strlen(last_slash++), sizeof(char));
    strcpy(base, last_slash);
  }
  return base;
}

static void fatal_error(char* format, ...) {
  va_list ap;

  fprintf(stderr, "Error: ");
  va_start(ap, format);
  vfprintf(stderr, format, ap);
  va_end(ap);
  fprintf(stderr, "\n");
  abort();
}

static int export_features(char* filename, struct feature* feat, int n) {
  int r, type;

  if (n <= 0 || ! feat) {
    fprintf(stderr, "Waring: no features to export, %s line %d\n",
            __FILE__, __LINE__);
    return 1;
  }

  r = export_lowe_features(filename, feat, n);

  if (r)
    fprintf(stderr, "Warring: unable to export features to %s,"    \
           " %s, line %d\n", filename, __FILE__, __LINE__);
  return r;
}

static int export_lowe_features(char* filename, struct feature* feat, int n) {
  FILE* file;
  int i, j, d;

  if (n <= 0) {
    fprintf(stderr, "Warning: feature count %d, %s, line %d\n",
            n, __FILE__, __LINE__);
    return 1;
  }

  if (! (file = fopen(filename, "w"))) {
    fprintf(stderr, "Warning: error opening %s, %s, line %d\n",
            filename, __FILE__, __LINE__);
    return 1;
  }

  d = feat[0].d;
  fprintf(file, "%d %d\n", n, d);
  for (i = 0; i < n; i++) {
    fprintf(file, "%f %f %f %f", feat[i].y, feat[i].x, feat[i].scl,
            feat[i].ori);
    for (j = 0; j < d; j++) {
      if (j % 20 == 0)
        fprintf(file, "\n");
      fprintf(file, " %d", (int)(feat[i].descr[j]));
    }
    fprintf(file, "\n");
  }

  if (fclose(file)) {
    fprintf(stderr, "Warning: file close error, %s, line %d\n",
            __FILE__, __LINE__);
    return 1;
  }
  return 0;
}

